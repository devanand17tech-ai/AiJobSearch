import os
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv

load_dotenv()

class ApifyJobClient:
    """
    Communicates with the Apify API using the official apify-client Python package.
    Executes configured job scraper actors (e.g. apify/google-jobs-scraper) to fetch live job listings.
    """

    def __init__(self, api_token: Optional[str] = None, actor_id: Optional[str] = None):
        self.api_token = api_token or os.getenv("APIFY_API_TOKEN", "").strip()
        self.actor_id = actor_id or os.getenv("APIFY_ACTOR_ID", "apify/google-jobs-scraper").strip()
        
        self.client = None
        if self.api_token:
            try:
                from apify_client import ApifyClient
                self.client = ApifyClient(token=self.api_token)
            except ImportError:
                print("[ApifyJobClient Warning] apify-client package not installed.")
            except Exception as e:
                print(f"[ApifyJobClient Error] Failed to initialize ApifyClient: {e}")

    def is_configured(self) -> bool:
        """Returns True if Apify token is provided and client initialized."""
        return bool(self.api_token and self.client is not None)

    def search_jobs(self, query: str, location: str = "", max_results: int = 10) -> List[Dict[str, Any]]:
        """
        Executes an Apify Actor to fetch live jobs matching the search query and location.
        """
        if not self.is_configured():
            print("[ApifyJobClient] Live job search is not configured (missing APIFY_API_TOKEN).")
            return []

        try:
            print(f"[ApifyJobClient] Launching Actor '{self.actor_id}' for query: '{query}', location: '{location}'")
            
            # Configure input for standard Apify Google Jobs Scraper or generic job actor
            run_input = {
                "queries": f"{query} in {location}".strip() if location else query,
                "maxItems": max_results,
                "maxPages": 1,
            }

            # Run the actor synchronously and wait for completion
            run = self.client.actor(self.actor_id).call(run_input=run_input, timeout_secs=120)

            # Fetch dataset items
            dataset_items = []
            if run and "defaultDatasetId" in run:
                dataset_client = self.client.dataset(run["defaultDatasetId"])
                dataset_items = list(dataset_client.iterate_items())
                print(f"[ApifyJobClient] Successfully fetched {len(dataset_items)} items from Apify Dataset.")

            return dataset_items

        except Exception as e:
            print(f"[ApifyJobClient Error] Apify actor run failed: {str(e)}")
            return []
